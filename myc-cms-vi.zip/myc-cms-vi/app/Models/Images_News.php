<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Images_News extends Model
{
    protected $table = 'images_news';
    protected $guarded = [];
    public $timestamps = false;
}