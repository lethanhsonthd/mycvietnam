<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Dangki extends Model
{
    protected $table = 'dangki';
}
