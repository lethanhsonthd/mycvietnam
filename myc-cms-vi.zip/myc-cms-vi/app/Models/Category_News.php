<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category_News extends Model
{
    protected $table = 'category_news';
    protected $guarded = [];
    public $timestamps = false;
}
