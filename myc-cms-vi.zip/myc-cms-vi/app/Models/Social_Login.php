<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Social_Login extends Model
{
    protected $table = 'social_login';
    protected $guarded = [];
}
