<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category_Product extends Model
{
    protected $table = 'category_product';
    protected $guarded = [];
    public $timestamps = false;
}
