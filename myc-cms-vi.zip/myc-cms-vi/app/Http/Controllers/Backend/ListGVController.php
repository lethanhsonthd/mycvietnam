<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Dangkigiaovien;
class ListGVController extends Controller
{
    public function destroy($id)
    {
        $post  = Dangkigiaovien::findOrFail($id);
        $post->delete();
        return redirect()->route('list-gv');
    }
}
