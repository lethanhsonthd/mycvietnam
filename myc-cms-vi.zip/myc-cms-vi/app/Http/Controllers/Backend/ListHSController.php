<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Dangki;
class ListHSController extends Controller
{
    public function destroy($id)
    {
        $post  = Dangki::findOrFail($id);
        $post->delete();
        return redirect()->route('list-hs');
    }
}
