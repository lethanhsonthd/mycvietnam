<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\News;
use App\Models\Category_News;
use App\Models\Post;
use App\Models\Dangki;
use App\Models\Category;
use App\Models\Dangkigiaovien;
use Illuminate\Support\Facades\DB;
class MainController extends Controller
{
    public function gioi_thieu(){
    	return view('frontend.master');
    }
    public function trang_chu(){
    	$capdo = DB::table('news')->
    	join('category_news','news.id','=','category_news.news_id')->where('category_id',1)->skip(1)->first(); 
    	$cohoi = DB::table('news')->
    	join('category_news','news.id','=','category_news.news_id')->where('category_id',1)->skip(0)->first(); 
    	$thongtin = DB::table('news')->
    	join('category_news','news.id','=','category_news.news_id')->where('category_id',1)->skip(2)->first(); 
    	return view('frontend.pages.trang-chu',['cohoi'=>$cohoi,'capdo'=>$capdo,'thongtin'=>$thongtin]);
    }
    public function mau_dang_ki_hoc(){
    	return view('frontend.blocks.mau-dang-ki-hoc');
    }
    public function tin_tuc(){
    	$posts = Post::select('id','image','title','content')->get();
    	return view('frontend.pages.tin-tuc',['posts'=>$posts]);
    }
    public function chi_tiet_tin_tuc($id){
        $post = Post::select('id','image','title','content','title_tag','meta_keywords_tag','meta_description_tag','slug')->find($id);
    	return view('frontend.pages.chi-tiet-tin-tuc',['post'=>$post]);
    }
    public function one_column(){
    	return view('frontend.pages.one-column');
    }
    public function gioi_thieu_chuong_trinh(){
    	$intro = DB::table('news')->
    	join('category_news','news.id','=','category_news.news_id')->where('category_id',4)->select('title','image','content')->orderBy('news.id','asc')->first();	
    	$posts = DB::table('news')->
    	join('category_news','news.id','=','category_news.news_id')->where('category_id',4)->select('title','image','content')->orderBy('news.id','asc')->skip(1)->take(1000)->get();	
    	return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$intro]);
    }
    public function nhung_loi_ich(){
    	$loiich = DB::table('news')->
    	join('category_news','news.id','=','category_news.news_id')->where('category_id',6)->select('title','image','content')->orderBy('news.id','asc')->first();
    	return view('frontend.pages.nhung-loi-ich',['loiich'=>$loiich]);
    }
    public function khoa_hoc_sunrise(){
        $sunrise = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',16)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts ="";
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$sunrise]);
    }
    public function khoa_hoc_sunshine(){
        $sunshine = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',17)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',17)->select('title','image','content')->orderBy('news.id','asc')->skip(1)->take(1000)->get();
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$sunshine]);
    }
    public function khoa_hoc_sunbeams(){
        $sunbeams = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',18)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',18)->select('title','image','content')->orderBy('news.id','asc')->skip(1)->take(1000)->get();
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$sunbeams]);
    }
    public function khoa_hoc_moonbeams(){
        $moonbeams = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',19)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',19)->select('title','image','content')->orderBy('news.id','asc')->skip(1)->take(1000)->get();
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$moonbeams]);
    }
    public function khoa_hoc_newchoice(){
        $newchoice = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',20)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts ="";
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$newchoice]);
    }

    public function khoa_hoc_your_best_choice(){
        $bestchoice = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',21)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts ="";
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$bestchoice]);
    }
    public function test_dang_ki(){
    	return view('frontend.pages.test-dang-ki-hoc');
    }
    public function test_submit_form_get(){
    	$navbar = Category::where('parent_id',8)->select('name','id')->get();
    	return view('frontend.pages.test-dang-ki-hoc',['navbar'=>$navbar]);
    }
    public function test_submit_form_post(Request $request){
    	$dangki = new Dangki;
    	$dangki->hoten 			= $request->submitted['hoten'];
    	$dangki->sdt 			= $request->submitted['sdt'];
    	$dangki->email 			= $request->submitted['email'];
    	$dangki->diachi 		= $request->submitted['diachi'];
    	$dangki->thongtinkhac 	= $request->submitted['thongtinkhac'];
    	$dangki->hotenbe 		= $request->submitted['hotenbe'];
    	$ngay_sinh              = $request->submitted['ngay_sinh']['day'];
        $thang_sinh             = $request->submitted['ngay_sinh']['month'];
        $ngay_sinh              = $request->submitted['ngay_sinh']['day'];
        $nam_sinh               = $request->submitted['ngay_sinh']['year'];
        $time = $ngay_sinh.' '.$thang_sinh.' '.$nam_sinh;
        $dangki->ngaysinh       = $time;
    	$dangki->chuongtrinhhoc	= $request->submitted['chuongtrinhhoc'];
    	$dangki->diadiemhoc 	= $request->submitted['diadiemhoc'];
        $dangki->status         = "off";
    	$dangki->save();
    	return redirect()->route('trang-chu');
    }
    public function submit_giao_vien_get(){
        return view('frontend.blocks.mau-dang-ki-day');
    }
    public function submit_giao_vien_post(Request $request){
        $giaovien = new Dangkigiaovien;
        $giaovien->hoten        = $request->submitted['hoten'];
        $giaovien->namsinh      = $request->submitted['namsinh'];
        $giaovien->sdt          = $request->submitted['sdt'];
        $giaovien->email        = $request->submitted['email'];
        $giaovien->diachi       = $request->submitted['diachi'];
        $giaovien->diachidangkilamviec    = $request->submitted['diadiemdangkilamviec'];
        $giaovien->bangcap      = $request->submitted['bangcap'];
        $giaovien->status       = "off";
        $giaovien->save();
        return redirect()->route('trang-chu');
    }

    public function mau_dang_ki_giao_vien(){
        $dangkigv = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',24)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts ="";
        return view('frontend.pages.dang-ki-giao-vien',['posts'=>$posts,'intro'=>$dangkigv]);
    }
    public function yeu_cau_giao_vien_MYC(){
        $yeucaugv = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',23)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts="";
        return view('frontend.pages.yeu-cau-de-tro-thanh-gv',['posts'=>$posts,'intro'=>$yeucaugv]);
    }
    public function tai_sao_nen_tro_thanh_gv_MYC(){
        $taisao = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',22)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts="";
        return view('frontend.pages.yeu-cau-de-tro-thanh-gv',['posts'=>$posts,'intro'=>$taisao]);
    }
    public function lien_ket(){
        $lienket = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',12)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts="";
        return view('frontend.pages.yeu-cau-de-tro-thanh-gv',['posts'=>$posts,'intro'=>$lienket]);
    }
    public function lien_he(){
        $lienhe = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',13)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts="";
        return view('frontend.pages.yeu-cau-de-tro-thanh-gv',['posts'=>$posts,'intro'=>$lienhe]);
    }
    public function lich_su_myc(){
        $lichsu = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',14)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts="";
        return view('frontend.pages.gioi-thieu-chuong-trinh',['posts'=>$posts,'intro'=>$lichsu]);
    }
    public function get_list_hs(){
        $hocsinh = Dangki::select('id','hoten','sdt','email','diachi','thongtinkhac','hotenbe','ngaysinh','chuongtrinhhoc','diadiemhoc')->orderBy('id','desc')->get();
        return view('backend.module.list.listhocsinh',['posts'=>$hocsinh]);
    }
    public function get_list_gv(){
        $giaovien = Dangkigiaovien::select('id','hoten','sdt','email','diachi','diachidangkilamviec','namsinh','bangcap')->orderBy('id','desc')->get();
        return view('backend.module.list.listgiaovien',['posts'=>$giaovien]);
    }
    public function chuong_trinh_hoc(){
        $cth = DB::table('news')->
        join('category_news','news.id','=','category_news.news_id')->where('category_id',25)->select('title','image','content')->orderBy('news.id','asc')->first();
        $posts="";
        return view('frontend.pages.chuong-trinh-hoc',['posts'=>$posts,'cth'=>$cth]);
    }
}
