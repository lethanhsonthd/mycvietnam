<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDangkiTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dangki', function (Blueprint $table) {
            $table->increments('id');
            $table->string('hoten')->nullable();
            $table->string('sdt')->nullable();
            $table->string('email')->nullable();
            $table->string('diachi')->nullable();
            $table->string('thongtinkhac')->nullable();
            $table->string('hotenbe')->nullable();
            $table->string('ngaysinh')->nullable();
            $table->string('chuongtrinhhoc')->nullable();
            $table->string('diadiemhoc')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dangki');
    }
}
