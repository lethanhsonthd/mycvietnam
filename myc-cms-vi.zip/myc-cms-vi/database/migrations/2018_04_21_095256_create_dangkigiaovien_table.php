<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDangkigiaovienTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dangkigiaovien',function(Blueprint $table){
            $table->increments('id')->nullable();
            $table->string('hoten')->nullable();
            $table->string('namsinh')->nullable();
            $table->string('sdt')->nullable();
            $table->string('email')->nullable();
            $table->string('diachi')->nullable();
            $table->string('diachidangkilamviec')->nullable();
            $table->string('bangcap')->nullable();
            $table->string('status')->nullable();
            $table->timestamps();
        }); 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
