<?php 
function share_all_view () {
	$param = "Hello View";
	return $param;
}
?>